// find_safe_citizens.h
#ifndef FIND_SAFE_CITIZENS_H
#define FIND_SAFE_CITIZENS_H

#include <semaphore.h>

typedef struct {
    int number_of_solutions;
    int iterations;
    sem_t semaphore;
} SharedMemory;

void find_safe_citizens(SharedMemory *memory, int num_processes, int max_solutions, int supermarkets[]);

#endif // FIND_SAFE_CITIZENS_H
