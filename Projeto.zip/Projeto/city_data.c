// city_data.c
#include "city_data.h"
#include <stdio.h>
#include <stdlib.h>

int read_city_data(const char *filename, CityData *data) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erro ao abrir o arquivo");
        return -1;
    }

    if (fscanf(file, "%d %d", &data->num_avenues, &data->num_streets) != 2) {
        perror("Erro ao ler número de avenidas e ruas");
        fclose(file);
        return -1;
    }

    if (fscanf(file, "%d %d", &data->num_supermarkets, &data->num_citizens) != 2) {
        perror("Erro ao ler número de supermercados e cidadãos");
        fclose(file);
        return -1;
    }

    for (int i = 0; i < data->num_supermarkets; i++) {
        if (fscanf(file, "%d %d", &data->supermarkets[i].avenue, &data->supermarkets[i].street) != 2) {
            perror("Erro ao ler localização de supermercado");
            fclose(file);
            return -1;
        }
    }

    for (int i = 0; i < data->num_citizens; i++) {
        if (fscanf(file, "%d %d", &data->citizens[i].avenue, &data->citizens[i].street) != 2) {
            perror("Erro ao ler localização de cidadão");
            fclose(file);
            return -1;
        }
    }

    fclose(file);
    return 0;
}
