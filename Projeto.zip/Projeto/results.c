// results.c
#include "results.h"
#include <time.h>
#include <stdio.h>

long calculate_time_ms(struct timespec start, struct timespec end) {
    return (end.tv_sec - start.tv_sec) * 1000 + (end.tv_nsec - start.tv_nsec) / 1000000;
}

void execute_test(TestResult *results, CityData *data, int num_processes, int max_solutions) {
    struct timespec start_total, end_total, start_solution, end_solution;
    clock_gettime(CLOCK_MONOTONIC, &start_total);

    SharedMemory memory = {.number_of_solutions = 0, .iterations = 0};
    sem_init(&memory.semaphore, 1, 1);

    int supermarkets[MAX_SUPERMARKETS];
    for (int i = 0; i < data->num_supermarkets; i++) {
        supermarkets[i] = data->supermarkets[i].avenue * data->num_streets + data->supermarkets[i].street;
    }

    clock_gettime(CLOCK_MONOTONIC, &start_solution);
    find_safe_citizens(&memory, num_processes, max_solutions, supermarkets);
    clock_gettime(CLOCK_MONOTONIC, &end_solution);

    results->safe_citizens_count = memory.number_of_solutions;
    results->iterations = memory.iterations;
    results->time_to_solution = calculate_time_ms(start_solution, end_solution);

    clock_gettime(CLOCK_MONOTONIC, &end_total);
    results->execution_time = calculate_time_ms(start_total, end_total);

    sem_destroy(&memory.semaphore);
}

void calculate_and_display_results(TestResult *results, int num_repeats, int test_num) {
    long total_exec_time = 0, total_time_to_solution = 0;
    int total_iterations = 0, optimal_solution_count = 0;
    int optimal_result = results[0].safe_citizens_count;

    for (int i = 0; i < num_repeats; i++) {
        total_exec_time += results[i].execution_time;
        total_time_to_solution += results[i].time_to_solution;
        total_iterations += results[i].iterations;

        if (results[i].safe_citizens_count == optimal_result) {
            optimal_solution_count++;
        }
    }

    printf("Teste %d\n", test_num);
    printf("Tempo médio de execução: %ld ms\n", total_exec_time / num_repeats);
    printf("Tempo médio até a solução: %ld ms\n", total_time_to_solution / num_repeats);
    printf("Média de iterações: %d\n", total_iterations / num_repeats);
    printf("Soluções ótimas encontradas: %d/%d\n\n", optimal_solution_count, num_repeats);
}
