// main.c
#include "city_data.h"
#include "results.h"
#include <stdio.h>
#include <stdlib.h>

#define NUM_REPEATS 10

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Uso: %s <arquivo_problema> <num_processos> <tempo_maximo_ms>\n", argv[0]);
        return 1;
    }

    const char *filename = argv[1];
    int num_processes = atoi(argv[2]);
    int max_time_ms = atoi(argv[3]);

    CityData data;
    if (read_city_data(filename, &data) != 0) {
        fprintf(stderr, "Erro ao carregar os dados da cidade.\n");
        return 1;
    }

    TestResult results[NUM_REPEATS];
    for (int i = 0; i < NUM_REPEATS; i++) {
        execute_test(&results[i], &data, num_processes, data.num_citizens);
    }

    calculate_and_display_results(results, NUM_REPEATS, 1);
    return 0;
}
