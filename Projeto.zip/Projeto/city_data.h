// city_data.h
#ifndef CITY_DATA_H
#define CITY_DATA_H

#define MAX_SUPERMARKETS 10
#define MAX_CITIZENS 50

typedef struct {
    int avenue;
    int street;
} Location;

typedef struct {
    int num_avenues;
    int num_streets;
    int num_supermarkets;
    int num_citizens;
    Location supermarkets[MAX_SUPERMARKETS];
    Location citizens[MAX_CITIZENS];
} CityData;

int read_city_data(const char *filename, CityData *data);

#endif // CITY_DATA_H
