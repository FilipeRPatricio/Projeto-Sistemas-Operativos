// results.h
#ifndef RESULTS_H
#define RESULTS_H

#include "city_data.h"

typedef struct {
    long execution_time;
    long time_to_solution;
    int safe_citizens_count;
    int iterations;
} TestResult;

long calculate_time_ms(struct timespec start, struct timespec end);
void execute_test(TestResult *results, CityData *data, int num_processes, int max_solutions);
void calculate_and_display_results(TestResult *results, int num_repeats, int test_num);

#endif // RESULTS_H
